# importing the necessary dependencies
import pickle


from flask import Flask, render_template, request
from flask_cors import cross_origin
import Preprocessing

app = Flask(__name__)  # initializing a flask app


@app.route('/', methods=['GET'])  # route to display the home page
@cross_origin()
def homePage():
    return render_template("index.html")


@app.route('/predict', methods=['POST', 'GET'])  # route to show the predictions in a web UI
@cross_origin()
def index():
    if request.method == 'POST':
        try:
            #  reading the inputs given by the user
            #  reading the inputs given by the user
            LIMIT_BAL = float(request.form['LIMIT_BAL'])
            SEX = float(request.form['SEX'])
            AGE = float(request.form['AGE'])
            PAY_1 = float(request.form['PAY_1'])
            PAY_2 = float(request.form['PAY_2'])
            PAY_3 = float(request.form['PAY_3'])
            PAY_4 = float(request.form['PAY_4'])
            PAY_AMT1 = float(request.form['PAY_AMT1'])
            PAY_AMT2 = float(request.form['PAY_AMT2'])
            PAY_AMT3 = float(request.form['PAY_AMT3'])
            PAY_AMT4 = float(request.form['PAY_AMT4'])
            PAY_AMT5 = float(request.form['PAY_AMT5'])
            PAY_AMT6 = float(request.form['PAY_AMT6'])
            EDUCATION = float(request.form['EDUCATION'])
            MARRIAGE = float(request.form['MARRIAGE'])

            filename = 'CCD_model_final_v3.pickle'
            loaded_model = pickle.load(open(filename, 'rb'))  # loading the model file from the storage
            # predictions using the loaded model file
            #prediction = loaded_model.predict([[crim,ZN,INDUS,CHAS,NOX,RM,AGE,DIS,RAD,TAX,PTRATIO,B,LSTAT]])

            df = [LIMIT_BAL, SEX, AGE, PAY_1, PAY_2, PAY_3, PAY_4, PAY_AMT1, PAY_AMT2, PAY_AMT3, PAY_AMT4, PAY_AMT5, PAY_AMT6, EDUCATION, MARRIAGE]
            print(df)
            df = Preprocessing.onehot_encode(df,{'EDUCATION': 'EDU','MARRIAGE': 'MAR'})
            print(df)
            df = Preprocessing.preprocess_inputs(df)
            print(df)
            prediction = loaded_model.predict([[df.values[0]]])
            print('prediction is', prediction)
            # showing the prediction results in a UI
            return render_template('results.html', prediction=prediction[0])
        except Exception as e:
            print('The Exception message is: ', e)

            return 'something is wrong'
    # return render_template('results.html')
    else:
        return render_template('index.html')


if __name__ == "__main__":
    # app.run(host='127.0.0.1', port=8001, debug=True)
    app.run(debug=True)  # running the app
